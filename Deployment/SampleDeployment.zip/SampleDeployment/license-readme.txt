Military Symbols.NET - https://github.com/csmoore/military-symbols-dotnet

Apache License, Version 2.0

For source/credits/license see: https://github.com/csmoore/military-symbols-dotnet

1. SVG and data files from https://github.com/Esri/joint-military-symbology-xml/ 
    1. Governed by the Apache License, Version 2.0, http://www.apache.org/licenses/LICENSE-2.0

2. The C# SVG Rendering Engine svg.dll 
    1.  The C# SVG Rendering Engine is governed by the Microsoft Public License: https://svg.codeplex.com/license
    2.  For more information see the project pages at:
        1.  http://svg.codeplex.com/
        2.  https://github.com/vvvv/SVG 